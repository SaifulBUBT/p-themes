<?php 
  // Style and scripts cash basting
  if(site_url() == "http://localhost/consult"){
    define('VERSION',time());
  } else{
    define('VERSION',wp_get_theme()->get('VERSION'));
  }

function philosophy_assets(){
  wp_enqueue_style( "fontawesome-css", get_theme_file_uri("/assets/css/font-awesome/css/font-awesome.min.css"), null, "1.0" );
  wp_enqueue_style( "font-css", get_theme_file_uri("/assets/css/fonts.css"), null, "1.0" );
  wp_enqueue_style("base-css", get_theme_file_uri("/assets/css/base.css"),null ,"1.0");
  wp_enqueue_style("vendor-css", get_theme_file_uri("/assets/css/vendor.css"),null ,"1.0");
  wp_enqueue_style("main-css", get_theme_file_uri("/assets/css/main.css"),null ,"1.0");
  wp_enqueue_style("philosophy-css", get_stylesheet_uri(),null, VERSION);

  wp_enqueue_script("modernizr-js",get_theme_file_uri("/assets/js/modernizr.js"),null, "1.0");
  wp_enqueue_script("pace-js",get_theme_file_uri("/assets/js/pace.min.js"),null, "1.0");
  wp_enqueue_script("plugin-js",get_theme_file_uri("/assets/js/plugins.js"),array("jquery"), "1.0", true);
  wp_enqueue_script("main-js",get_theme_file_uri("/assets/js/main.js"),array("jquery"), VERSION, true);

}
?>