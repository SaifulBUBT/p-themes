<?php 
define( 'ATTACHMENTS_SETTINGS_SCREEN', false ); // disable the Settings screen
add_filter( 'attachments_default_instance', '__return_false' ); // disable the default instance

function philosophy_attachments($attachments){

  // when post format is Gallery then show this field section
  $post_id = null;
  if(isset($_REQUEST['post']) || isset($_REQUEST['post_ID'])){
    $post_id = empty($_REQUEST['post_ID']) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
  }
  if(!$post_id || get_post_format($post_id) != "gallery"){
    return;
  }

  $fields = array(
    array(
      'name' => 'title',
      'type' => 'text',
      'label' => __('Title', 'philosophy'),
      'default' => 'title',
    ),
  );

  $args = array(
        // title of the meta box (string)
        'label'         => 'Attach Gallery Image',

        // all post types to utilize (string|array)
        'post_type'     => array( 'post' ),
    
        // meta box position (string) (normal, side or advanced)
        'position'      => 'normal',
    
        // meta box priority (string) (high, default, low, core)
        'priority'      => 'high',
    
        // allowed file type(s) (array) (image|video|text|audio|application)
        'filetype'      => null,  // no filetype limit
    

    
        // text for 'Attach' button in meta box (string)
        'button_text'   => __( 'Attach Files', 'philosophy' ),

    
        // fields array
        'fields'        => $fields,
  );

  $attachments->register( 'gallery_post', $args ); // unique instance name

}

add_action( 'attachments_register', 'philosophy_attachments' );
?>