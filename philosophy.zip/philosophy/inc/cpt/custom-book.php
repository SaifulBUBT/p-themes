<?php
function philosophy_register_my_cpts_book() {

	/**
	 * Post Type: Books.
	 */

	$labels = array(
		"name" => __( "Books", "philosophy" ),
		"singular_name" => __( "Book", "philosophy" ),
		"all_items" => __( "My All Books", "philosophy" ),
		"menu_name" => __( "My Books", "philosophy" ),
		"add_new" => __( "Add New Book", "philosophy" ),
		"edit_item" => __( "Edit Book", "philosophy" ),
		"new_item" => __( "New Book", "philosophy" ),
		"view_item" => __( "View Book", "philosophy" ),
		"view_items" => __( "View Books", "philosophy" ),
		"search_items" => __( "Search Book", "philosophy" ),
		"not_found" => __( "No Books Found", "philosophy" ),
		"featured_image" => __( "Book Cover Image", "philosophy" ),
		"archives" => __( "Book Archives", "philosophy" ),
	);

	$args = array(
		"label" => __( "Books", "philosophy" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => "books",
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "book", "with_front" => false ),
		"query_var" => true,
		"menu_position" => 21,
		"menu_icon" => "dashicons-book-alt",
		"supports" => array( "title", "editor", "thumbnail", "excerpt", "custom-fields", "comments", "author" ),
	);

	register_post_type( "book", $args );
}

add_action( 'init', 'philosophy_register_my_cpts_book' );

 ?>