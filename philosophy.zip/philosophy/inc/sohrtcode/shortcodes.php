<?php 

function philosophy_buttons($attributes){

	$default = array(
		'type'  => 'primary',
		'url'   => '',
		'title' => __('Button', 'philosophy'),
	);

	$button_attributes = shortcode_atts( $default, $attributes );

	return sprintf(' <a class="btn btn--%s full-width" href="%s">%s</a>',
		$button_attributes['type'],
		$button_attributes['url'],
		$button_attributes['title']
		);
}
add_shortcode('button', 'philosophy_buttons' );


function philosophy_button2($attributes, $content = ''){
	$default = array(
		'type'  => 'stroke',
		'url'   => '',
	);

	$button_attributes = shortcode_atts( $default, $attributes );
	return sprintf(' <a target="_blank" class="btn btn--%s full-width" href="%s">%s</a>',
		$button_attributes['type'],
		$button_attributes['url'],
		do_shortcode( $content )
		);
}
add_shortcode( 'button2', 'philosophy_button2' );


function philosophy_lowercase($attributes, $content = ''){
	return strtolower(do_shortcode( $content));
}
add_shortcode( 'lp', 'philosophy_lowercase' );


// shortcode for alert boxs

function philosophy_alert_box($attributes, $content = ''){
	$default = array(
		'type' => 'info',
	);

	$alert_attributes = shortcode_atts( $default, $attributes );
	return sprintf(' <div class="alert-box alert-box--%s hideit">
                    <p>%s</p>
                    <i class="fa fa-times alert-box__close"></i>
                	</div>',

                	$alert_attributes['type'],
                	$content

            );
}
add_shortcode('alert', 'philosophy_alert_box');

// shortcode for code

function philosophy_code($attributes, $content = ''){
	return ('<pre><code>'.$content.'</code></pre>');
}
add_shortcode( 'code', 'philosophy_code' );

// shortcode for google maps
function philosophy_google_map($attributes){
    $default = array(
        'place'=>'Dhaka Museum',
        'width'=>'800',
        'height'=>'500',
        'zoom'=>'14'
    );
    $map_attributes = shortcode_atts($default,$attributes);
    $map = <<<EOD
<div>
    <div>
        <iframe width="{$map_attributes['width']}" height="{$map_attributes['height']}"
                src="https://maps.google.com/maps?q={$map_attributes['place']}&t=&z={$map_attributes['zoom']}&ie=UTF8&iwloc=&output=embed"
                frameborder="0" scrolling="no" marginheight="0" marginwidth="0">
        </iframe>
    </div>
</div>
EOD;
    return $map;
}
add_shortcode('gmap','philosophy_google_map');

// shortcode for box

function philosophy_box($attributes, $content = '') {
	$default = array(
		'color' => '#0f0'
	);
	$box_atts = shortcode_atts( $default, $attributes );
	return sprintf('<div style="border:2px solid #ddd; margin:10px 0; padding: 5px; color:%s;">%s</div>',
		$box_atts['color'],
		$content
		);
}
add_shortcode( 'box', 'philosophy_box' );


function philosophy_youtube($attributes, $content = ''){
	return('<iframe width="560" height="315" src="https://www.youtube.com/embed/'.$content.'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>');
}
add_shortcode( 'youtube', 'philosophy_youtube' );


//shortcode for pull-quote
function philosophy_pull_quote($attributes, $content = ''){
	return('<aside class="pull-quote">
                    <blockquote>
                    <p>'.$content.'</p>
                    </blockquote>
                </aside>');
}
add_shortcode('pull', 'philosophy_pull_quote');

//shortecode for blockquote
function philosophy_blockquote($attributes, $content = ''){
	$default = array(
		'name' => 'Saiful'
	);
	$blockquote_atts = shortcode_atts( $default, $attributes );
	return ('<blockquote cite="http://where-i-got-my-info-from.com">
                <p>'.$content.'</p>
                <cite>
                    <a href="#">'.$blockquote_atts['name'].'</a>
                </cite>
                </blockquote>');
}
add_shortcode('blockquote', 'philosophy_blockquote');