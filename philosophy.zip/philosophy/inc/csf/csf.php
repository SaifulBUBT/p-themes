<?php

//***** page metabox start ********
function philosophy_csf_metabox(){
	CSFramework_Metabox::instance( array() );
}
add_action('init', 'philosophy_csf_metabox');


function philosophy_page_meta($options){

	$page_id = 0;
	if(isset($_REQUEST['post']) || isset($_REQUEST['post_ID'])){
		$page_id = empty($_REQUEST['post_ID']) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta( $page_id, '_wp_page_template', true );
	// if('about.php' != $corrent_page_template){
	if(!in_array($current_page_template, array('about.php','contact.php'))){
		return $options;
	}
	

	$options[] = array(
		'id'  => 'page_metabox',
		'title' => __('Page meta options', 'philosophy'),
		'post_type' => 'page',
		'context'  => 'normal',
		'priority' => 'default',
		'sections' => array(


			//begin sectoin
			array(
				'name'  => 'page-settings',
				'title' => __('Page Settings', 'philosophy'),
				'icon'  => 'fa fa-wifi',
				'fields' => array(

					array(
						'id' => 'page-heading',
						'title' => __('Heading','philosophy'),
						'type' => 'text',
					),
					array(
						'id' => 'page-teaser',
						'title' => __('Page Teaser', 'philosophy'),
						'type' => 'textarea',
					),
					array(
						'id' => 'is-favourite',
						'title' => __('Is Favourite', 'philosophy'),
						'type'  => 'switcher',
						'default' => 1,
					),
					array(
						'id' => 'favourite-text',
						'title' => __('Favourite Text', 'philosophy'),
						'type'  => 'text',
						'dependency' =>  array('is-favourite', '==', '1'),
					),

					array(
					  'id'           => 'color-select',
					  'type'         => 'select',
					  'title'        => 'Select color black or white',
					  'options'      => array(
					    'blue'       => 'Blue',
					    'yellow'     => 'Yellow',
					    'green'      => 'Green',
					    'black'      => 'Black',
					    'white'      => 'White',
					  ),
					),
					array(
					  'id'        => 'page_image',
					  'type'      => 'image',
					  'title'     => __('Upload Image','philosophy'),
					  'add_title' => __('Add an image','philosophy'),
					),
					array(
					  'id'            => 'upload_pdf',
					  'type'          => 'upload',
					  'title'         => 'Upload File',
					  'settings'      => array(
					   'upload_type'  => 'application/pdf',
					   'button_title' => 'Upload PDF',
					   'frame_title'  => 'Select an PDF',
					   'insert_title' => 'Use this PDF',
					  ),
					),
					//Image gallery
					array(
					  'id'          => 'page_gallery',
					  'type'        => 'gallery',
					  'title'       => 'Image Gallery',
					  'add_title'   => 'Add Images',
					  'edit_title'  => 'Edit Images',
					  'clear_title' => 'Remove Images',
					),

					//Fieldset 
					array(
					  'id'        => 'philosophy_fieldset',
					  'type'      => 'fieldset',
					  'title'     => 'Fieldset Field',
					  'fields'    => array(

					    array(
					      'id'    => 'fieldset_1_text',
					      'type'  => 'text',
					      'title' => 'Text Field',
					    ),

					    array(
					      'id'    => 'fieldset_1_textarea',
					      'type'  => 'textarea',
					      'title' => __('Textarea Field', 'philosophy'),
					    ),
						  array(
						  'id'        => 'fieldset_image',
						  'type'      => 'image',
						  'title'     => __('Upload Image','philosophy'),
						  'add_title' => __('Add an image','philosophy'),
						),

					  ),
					),

					// Group fields
					array(
					  'id'              => 'unique_group_2',
					  'type'            => 'group',
					  'title'           => 'Group Field',
					  'desc'            => 'Accordion title using the ID of the field.',
					  'button_title'    => 'Add New',
					  'accordion_title' => 'unique_group_2_text_2',
					  'fields'          => array(

					    array(
					      'id'          => 'unique_group_2_text_1',
					      'type'        => 'text',
					      'title'       => 'Field Title 1',
					    ),

					    array(
					      'id'          => 'unique_group_2_text_2',
					      'type'        => 'text',
					      'title'       => 'Field Title 2',
					    ),

					    array(
					      'id'          => 'unique_group_2_text_3',
					      'type'        => 'textarea',
					      'title'       => 'Description Field',
					    ),

					  )
					),


				),
			),

			//begin sectoin
			array(
				'name'  => 'page-settings2',
				'title' => __('Page Settings2', 'philosophy'),
				'icon'  => 'fa fa-wifi',
				'fields' => array(

					array(
						'id' => 'page-sub-title',
						'title' => __('SubTtile','philosophy'),
						'type' => 'text',
					),
					
				),
			),


		),

	);


	return $options;
}
add_filter('cs_metabox_options', 'philosophy_page_meta');

//***** page metabox end ********



//Code for Theme options Start*************

function philosophy_theme_option_init(){

	$settings = array(
		'menu_title'      => __('Philosophy Options', 'philosophy'),
		'menu_type'       => 'menu',
		'menu_slug'  	  => 'philosophy_option_panel',
		'ajax_save'       => false,
  		'show_reset_all'  => true,
  		'framework_title' => __('Philosophy Options', 'philosophy'),
  		'menu_position'   => 75,
  		'menu_icon'       => 'dashicons-dashboard'
  	);

  	CSFramework::instance( $settings, array() );
}
add_action( "init", "philosophy_theme_option_init" );


function philosophy_theme_options($options){

	  $options[]    = array(
	    'name'      => 'footer_options',
	    'title'     => __('Footer Options', 'philosophy'),
	    'icon'      => 'fa fa-heart',
	    'fields'    => array(
	      array(
	        'id'    => 'footer_tag',
	        'type'  => 'switcher',
	        'title' => __('Want to see the tags on footer?','philosophy'),
	        'default' => 1
	      ),
	  
	    )
	  );

	  $options[]    = array(
	    'name'      => 'footer_social_area',
	    'title'     => __('Footer Social Area', 'philosophy'),
	    'icon'      => 'fa fa-heart',
	    'fields'    => array(
	      array(
	        'id'    => 'footer_facebook',
	        'type'  => 'text',
	        'title' => __('Type FB URL','philosophy'),
	      ),
	      array(
	        'id'    => 'footer_twitter',
	        'type'  => 'text',
	        'title' => __('Type twitter URL','philosophy'),
	      ),
	    )
	  );
	return $options;
}
add_filter('cs_framework_options', 'philosophy_theme_options' );


 ?>