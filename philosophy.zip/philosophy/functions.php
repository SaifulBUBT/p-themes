<?php 

//TGM plugin activation
require_once get_theme_file_path('/inc/tgm.php');

//Codestar framework
require_once get_theme_file_path('/lib/cs-framework/cs-framework.php');
require_once get_theme_file_path('/inc/csf/csf.php'); // write codes on this file for metabox, theme options, shortcodes texomoni etc

//Attachments plugin fields add
if ( class_exists( 'Attachments' ) ) {
  require_once get_theme_file_path('/inc/attachments.php');
}

// Register custom post type called book

require_once get_theme_file_path('/inc/cpt/custom-book.php');

// Register Shortcode
require_once get_theme_file_path('/inc/sohrtcode/shortcodes.php');

// widgets for social icon header and footer right
require_once get_theme_file_path('/widgets/social-icons-widget.php');

// philosophy_theme_setup
function philosophy_theme_setup(){

  load_theme_textdomain( "philosophy" );
  add_theme_support( "title-tag" );
  add_theme_support("post-thumbnails");
  add_theme_support("custom-logo");
  add_theme_support("post-formats", array("image","link","gallery","quote","video","audio"));
  add_theme_support( 'html5', array( 'search-form' ) );
  add_editor_style( "/assets/css/editor-style.css" );

  add_image_size("philosophy-home-square",400,400,true);

  // nav menu registration
  register_nav_menu('mainmenu', __('Main Menu', 'philosophy'));
  register_nav_menus(array(
    'footer-left'  => __('Footer Left','philosophy'),
    'footer-right'  => __('Footer Right','philosophy'),
  ));
  
}
add_action("after_setup_theme","philosophy_theme_setup");

// Enqueue styles and sctipts
include_once('inc/enqueue-assets.php');
add_action("wp_enqueue_scripts", "philosophy_assets");

// Pagination with exact theme style
function philosophy_pagination(){
  global $wp_query;
  $links = paginate_links(  array(
    'current' => max(1, get_query_var('paged')),
    'total'   => $wp_query->max_num_pages,
    'type'    => 'list',
    'mid_size'=> 3,
  ));
  $links = str_replace('page-numbers', 'pgn__num', $links);
  $links = str_replace("<ul class='pgn__num'>", '<ul>', $links);
  $links = str_replace("next pgn__num", 'pgn__next', $links);
  $links = str_replace("prev pgn__num", 'pgn__prev', $links);

  echo $links;
}

// remove p tag from category description
remove_action( "term_description", "wpautop" );

// Widgets Register

function phisolophy_widgets(){
  register_sidebar(
    array(
      'name'          => __( 'About us page', 'philosophy' ),
      'id'            => 'about-us',
      'description'   => __('Add about us content', 'philosophy'),
      'before_widget' => '<div class="col-block">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3 class="quarter-top-margin">',
      'after_title'   => '</h3>',
    )
  );
  register_sidebar(
    array(
      'name'          => __( 'Contact us map section', 'philosophy' ),
      'id'            => 'contact-map',
      'description'   => __('Add contact map', 'philosophy'),
      'before_widget' => '<div id="map-wrap">',
      'after_widget'  => '</div>',
      'before_title'  => '',
      'after_title'   => '',
    )
  );
  register_sidebar(
    array(
      'name'          => __( 'Contact us Information section', 'philosophy' ),
      'id'            => 'contact-info',
      'description'   => __('Add contact information', 'philosophy'),
      'before_widget' => ' <div class="col-six tab-full">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3>',
      'after_title'   => '</h3>',
    )
  );
  register_sidebar(
    array(
      'name'          => __( 'before footer right section', 'philosophy' ),
      'id'            => 'before-footer-right-info',
      'description'   => __('Add before footer right information', 'philosophy'),
      'before_widget' => ' <div class="before-footer-right">',
      'after_widget'  => '</div>',
      'before_title'  => '<h3>',
      'after_title'   => '</h3>',
    )
  );
  register_sidebar(
    array(
      'name'          => __( 'header social section', 'philosophy' ),
      'id'            => 'header-social',
      'description'   => __('Add header social information', 'philosophy'),
      'before_widget' => ' <ul class="header__social">',
      'after_widget'  => '</ul>',
      'before_title'  => '<li>',
      'after_title'   => '</li>',
    )
  );
  register_sidebar(
    array(
      'name'          => __( 'footer archive section', 'philosophy' ),
      'id'            => 'footer-archive',
      'description'   => __('Add footer archive information', 'philosophy'),
      'before_widget' => ' <ul class="s-footer__linklist">',
      'after_widget'  => '</ul>',
      'before_title'  => '<li><a>',
      'after_title'   => '</a></li>',
    )
  );
  register_sidebar(
    array(
      'name'          => __( 'footer right section', 'philosophy' ),
      'id'            => 'footer-right',
      'description'   => __('Add footer right information', 'philosophy'),
      'before_widget' => ' <div class="footer-right">',
      'after_widget'  => '</div>',
      'before_title'  => '<h4>',
      'after_title'   => '</h4>',
    )
  );
  register_sidebar(
    array(
      'name'          => __( 'footer bottom section', 'philosophy' ),
      'id'            => 'footer-bottom',
      'description'   => __('Add footer bottom copyright information', 'philosophy'),
      'before_widget' => ' <div class="s-footer__copyright">',
      'after_widget'  => '</div>',
      'before_title'  => '',
      'after_title'   => '',
    )
  );
}
add_action("widgets_init", "phisolophy_widgets");


