<div id="comments" class="row">
      <div class="col-full">

          <h3 class="h2">
            <!--5 Comments-->

            <?php
              $philosophy_comment_no = get_comments_number();
              if($philosophy_comment_no <=1){
                echo $philosophy_comment_no." ".__("Comment", "philosophy");
              } else{
                echo $philosophy_comment_no." ".__("Comments", "philosophy");
              }
            ?>
          </h3>

          <!-- commentlist -->
          <ol class="commentlist">

              <?php wp_list_comments();?>
          </ol> <!-- end commentlist -->

          <div class="comments-navigation">
            <?php 
                the_comments_pagination(array(
                    'screen_reader_text' => __("Pagination", "philosophy"),
                    'prev_text' => '<'.' '.__('Previous','philosophy'),
                    'next_text' => '>'.' '.__('Next', 'philosophy'),

                ));
            ?>
          </div>

          <div class="comments-close">
            <?php
            if(!comments_open()){
                _e("Comments are closed", "philosophy");
            } 
            ?>
          </div>

          <!-- respond
          ================================================== -->
          <div class="respond">

              <h3 class="h2"><?php _e("Add Comment", "philosophy"); ?></h3>

                <?php 
                    	 $commenter = wp_get_current_commenter();
                       if ( ! isset( $args['format'] ) )
                   $args['format'] = current_theme_supports( 'html5', 'comment-form' ) ? 'html5' : 'xhtml';
                       $req = get_option( 'require_name_email' );
                       $aria_req = ( $req ? " aria-required='true'" : '' );
                       $html_req = ( $req ? " required='required'" : '' );
                   $html5    = 'html5' === $args['format'];
               
                   $comments_args = array(
                       // redefine your own textarea (the comment body)
                       'comment_field' => '<p class="comment-form-comment">
                       <textarea class="form-control" id="comment" name="comment" aria-required="true" placeholder="' . esc_attr__( "YOUR COMMENT", "text-domain" ) . '" rows="8" cols="37" wrap="hard"></textarea></p>',
                       'label_submit'         => esc_html__( 'POST A COMMENT', 'udemy' ),
                       'class_submit'         => 'submit submit-btn_ph',
                       'title_reply'          => esc_html__( 'ADD COMMENT', 'udemy' ),
                       'title_reply_before'   => '<h5 id="reply-title" class="comment-reply-title">',
                       'title_reply_after'    => '</h5>',
                 
                       
                       'comment_notes_before' => '<p class="comment-notes"><span id="email-notes">' . esc_html__( 'Your email address will not be published.', 'udemy' ) . '</span></p>',
                       
                       'fields' => apply_filters( 'comment_form_default_fields', array(
               
               
                                   
                           'email'  =>  '<input class="form-control" id="email" name="email" placeholder="' . esc_attr__( "E-mail*", "text-domain" ) . '" ' . ( $html5 ? 'type="email"' : 'type="text"' ) . ' size="30" maxlength="100" aria-describedby="email-notes"' . $aria_req . $html_req  . ' />',
                               
                           'url'    => '<input class="form-control" placeholder="' . esc_attr__( "WEBSITE", "text-domain" ) . '" id="url" name="url" ' . ( $html5 ? 'type="url"' : 'type="text"' ) . ' size="30" maxlength="200" />',
              
                
              
                           )
                         ),
              
              
                       );
                   comment_form($comments_args); 
                   
                ?>

          </div> <!-- end respond -->

      </div> <!-- end col-full -->

  </div> <!-- end row comments -->