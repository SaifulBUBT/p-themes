<?php
/***
 * Template Name: Book Page
 * ** */
?>

<?php get_header(); ?>



    <!-- s-content
    ================================================== -->
    <section class="s-content">
        
        <div class="row masonry-wrap">
            <div class="masonry">

                <div class="grid-sizer"></div>

                <?php 
                $paged = get_query_var('paged' )? get_query_var('paged') : 1;
                  $philosophy_books_arg = array(
                    'post_type'  => 'book',
                    'posts_per_page' => 3,
                    'paged' => $paged
                  );
                  $philosophy_books = new WP_Query($philosophy_books_arg);
                ?>

                <?php while($philosophy_books->have_posts()): $philosophy_books->the_post(); ?>
                    <?php get_template_part("template-parts/post-formats/post", get_post_format()); ?>
                <?php endwhile; ?>

            </div> <!-- end masonry -->
        </div> <!-- end masonry-wrap -->

        <div class="row">
            <div class="col-full">
                <nav class="pgn">
                    <!-- <ul>
                        <li><a class="pgn__prev" href="#0">Prev</a></li>
                        <li><a class="pgn__num" href="#0">1</a></li>
                        <li><span class="pgn__num current">2</span></li>
                        <li><a class="pgn__num" href="#0">3</a></li>
                        <li><a class="pgn__num" href="#0">4</a></li>
                        <li><a class="pgn__num" href="#0">5</a></li>
                        <li><span class="pgn__num dots">…</span></li>
                        <li><a class="pgn__num" href="#0">8</a></li>
                        <li><a class="pgn__next" href="#0">Next</a></li>
                    </ul> -->
                    
                    <?php
                        echo paginate_links( [
                            'current' => '$paged',
                            'total'  => $philosophy_books->max_num_pages,
                            'prev_next'=> false
                        ] );
                    ?>
                </nav>
            </div>
        </div>

    </section> <!-- s-content -->


    <!-- s-extra
    ================================================== -->
    <?php get_footer(); ?>