
<form role="search" method="get" class="header__search-form" action="<?php echo home_url('/'); ?>">
    <label>
        <span class="hide-content"><?php _e("Search for:", "philosphy"); ?></span>
        <input type="search" class="search-field" placeholder="<?php _e("Type Keywords", "philosphy"); ?>" value="" name="s" title="<?php _e("Search for:", "philosphy"); ?>" autocomplete="off">
    </label>

   <!-- for custom post type search-->
    <?php
        if(is_post_type_archive('book') || is_page( 'all-books')){ ?>
          <input type="hidden" name="post_type" value="book" >  
      <?php } else{?>
        <input type="hidden" name="post_type" value="post" >
     <?php } ?>
     <!-- for custom post type search-->

    <input type="submit" class="search-submit" value="<?php echo esc_attr_e( 'Search', 'philosophy' ) ?>">
</form>