<?php 
/*
Template Name: Contact page
*/
?>

<?php get_header(); ?>


    <!-- s-content
    ================================================== -->
    <section class="s-content s-content--narrow">

        <div class="row">

            <div class="s-content__header col-full">
                <h1 class="s-content__header-title">
                    <?php _e("Feel Free To Contact Us.", "philosophy");?>
                </h1>
            </div> <!-- end s-content__header -->
    
            <div class="s-content__media col-full">
                <!-- <div id="map-wrap">
                    <div id="map-container"></div>
                    <div id="map-zoom-in"></div>
                    <div id="map-zoom-out"></div>
                </div>  -->
                <?php
                  if(is_active_sidebar('contact-map')){
                    dynamic_sidebar('contact-map');
                  }
                ?>
            </div> <!-- end s-content__media -->

            <div class="col-full s-content__main">

                <?php 
                  while(have_posts()): the_post();
                ?>
                <?php the_content( ); ?>
                <?php endwhile;?>

                <div class="row">
                    <!-- <div class="col-six tab-full">
                        <h3>Where to Find Us</h3>

                        <p>
                        1600 Amphitheatre Parkway<br>
                        Mountain View, CA<br>
                        94043 US
                        </p>

                    </div> -->

                    <?php 
                      if(is_active_sidebar( 'contact-info' )){
                        dynamic_sidebar( 'contact-info' );
                      }
                    ?>
          
                </div> <!-- end row -->

                <h3><?php _e("Say Hello.", "philosophy");?></h3>

                      <!---code for contact form---->

                      <?php 
                        if(get_field("contact_form_shortcode")){
                          echo do_shortcode( get_field("contact_form_shortcode") );
                        }
                      ?>


            </div> <!-- end s-content__main -->

        </div> <!-- end row -->

    </section> <!-- s-content -->


    <?php  get_footer(); ?>