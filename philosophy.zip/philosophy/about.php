<?php
    /***
     * Template Name: About Page
     * * */
?>

<?php get_header(); ?>


    <!-- s-content
    ================================================== -->
    <section class="s-content s-content--narrow">

        <div class="row">

          <?php while(have_posts()) : the_post(); ?>
            <div class="s-content__header col-full">
                <h1 class="s-content__header-title">
                    <?php the_title(); ?>
                </h1>
            </div> <!-- end s-content__header -->

            <div class="s-content__media col-full">
                <div class="s-content__post-thumb">
                    <?php the_post_thumbnail( ); ?>
                </div>
            </div> <!-- end s-content__media -->

            <div class="col-full s-content__main">

                <?php the_content(); ?>
                <?php endwhile; ?>

                <div class="row block-1-2 block-tab-full">
                    <!-- <div class="col-block">
                        <h3 class="quarter-top-margin">Who We Are.</h3>
                        <p>Lorem ipsum Nisi amet fugiat eiusmod et aliqua ad qui ut nisi Ut aute anim mollit fugiat qui sit ex occaecat et eu mollit nisi pariatur fugiat deserunt dolor veniam reprehenderit aliquip magna nisi consequat aliqua veniam in aute ullamco Duis laborum ad non pariatur sit.</p>
                    </div> -->

                    <?php
                      if(is_active_sidebar('about-us')){
                        dynamic_sidebar('about-us'); 
                      }
                    ?>

                </div>

                <!-- csf page meta display-->
                <?php
                    $philosophy_page_meta = get_post_meta(get_the_ID(), 'page_metabox', true);
                    echo esc_html( $philosophy_page_meta['page-heading'] ).'</br>';
                    echo esc_html( $philosophy_page_meta['page-teaser'] ).'</br>';

                    if($philosophy_page_meta['is-favourite']){
                         echo esc_html( $philosophy_page_meta['favourite-text'] ).'</br>';
                    }

                    echo esc_html( $philosophy_page_meta['color-select'] ).'</br>';
                   
                    // codestar image field working
                    echo $philosophy_page_meta['page_image'].'</br>';

                    echo wp_get_attachment_image($philosophy_page_meta['page_image'], 'full').'</br>';

                 ?>
                 <img src="<?php echo wp_get_attachment_image_src( $philosophy_page_meta['page_image'], 'medium')[0];?>">

                 <?php 
                    //working with upload field
                    echo '</br>';
                    $file_url = $philosophy_page_meta['upload_pdf'];
                    echo esc_url( $file_url );

                    echo "<br /> <a href='{$file_url}' target='_blank'>Download PDF file</a>"
                 ?>
                 <?php 
                    // Image Gallery
                    echo '<br /> Image Gallery: ';
                    $gallery = $philosophy_page_meta['page_gallery'];
                    if($gallery){
                        $philosophy_gallery_ids = explode(',', $gallery);
                        foreach($philosophy_gallery_ids as $philosophy_gallery_id){
                            echo wp_get_attachment_image( $philosophy_gallery_id, 'medium' );
                        }

                    }


                    // Fieldset example
                    echo '<br /> Fieldset data example: ';

                    $fieldset_items = $philosophy_page_meta['philosophy_fieldset'];
                    // print_r($fieldset_items);
                    echo $fieldset_items['fieldset_1_text'];
                    echo '<br />';
                    echo $fieldset_items['fieldset_1_textarea'];
                    echo '<br />';
                    $philosophy_field_image = $fieldset_items['fieldset_image'];
                    echo wp_get_attachment_image( $philosophy_field_image, 'medium'); 

                    echo '<br />';

                    //Group items
                    echo '<h3>'.'Group items'. '</h3>';
                    $group_items = $philosophy_page_meta['unique_group_2'];
                    if($group_items){
                        foreach ($group_items as $group_item) {
                            echo $group_item['unique_group_2_text_1'].'<br />';
                            echo $group_item['unique_group_2_text_2'].'<br />';
                            echo $group_item['unique_group_2_text_3'].'<br /><br />';
                        }
                    }

                 ?>


            </div> <!-- end s-content__main -->

        </div> <!-- end row -->

    </section> <!-- s-content -->

<?php get_footer(); ?>