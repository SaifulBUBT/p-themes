<?php get_header(); ?>



    <!-- s-content
    ================================================== -->
    <section class="s-content">
        
        <div class="row masonry-wrap">
            <div class="masonry">

                <div class="grid-sizer"></div>
                    <?php if(!have_posts()){?>
                      <div class="container">
                          <div class="row">
                              <div class="col-md-12 text-center">
                                <h3>
                                  <?php
                                    _e("Sorry! No result found about ","philosophy");
                                    the_search_query();
                                  ?>
                                  </h3>
                              </div>
                          </div>
                      </div>
                  <?php } ?>

                <?php while(have_posts()): the_post(); ?>
                    <?php get_template_part("template-parts/post-formats/post", get_post_format()); ?>
                <?php endwhile; ?>

            </div> <!-- end masonry -->
        </div> <!-- end masonry-wrap -->

        <div class="row">
            <div class="col-full">
                <nav class="pgn">
                    <!-- <ul>
                        <li><a class="pgn__prev" href="#0">Prev</a></li>
                        <li><a class="pgn__num" href="#0">1</a></li>
                        <li><span class="pgn__num current">2</span></li>
                        <li><a class="pgn__num" href="#0">3</a></li>
                        <li><a class="pgn__num" href="#0">4</a></li>
                        <li><a class="pgn__num" href="#0">5</a></li>
                        <li><span class="pgn__num dots">…</span></li>
                        <li><a class="pgn__num" href="#0">8</a></li>
                        <li><a class="pgn__next" href="#0">Next</a></li>
                    </ul> -->
                    <?php philosophy_pagination(); ?>
                </nav>
            </div>
        </div>

    </section> <!-- s-content -->


    <!-- s-extra
    ================================================== -->
    <?php get_footer(); ?>